i = list(map(lambda x: list(map(int, x.split("."))), open("input.txt").read().split("\n")))

t = sorted(i[0])[:15] 
print(t)
sz = 1
for a in t:
    sz *= a
print(len(str(sz)))

parosok = [szam for szam in i[1] if szam % 2 == 0]
if len(parosok) == 0:
    minimum = None
else: minimum = min(parosok)
print(minimum)

harommal_oszthatoak = [szam for szam in i[2] if szam % 3 == 0]
osszegg = sum(harommal_oszthatoak)
print(osszegg)

maximum = max(i[3])
print(maximum)

kisebbek = [szam for szam in i[4] if szam < 15]
osszeg = sum([szam**2 for szam in kisebbek])
print(osszeg)

minden_szam = i[0] + i[1] + i[2] + i[3] + i[4]
legnagyobbak = sorted(minden_szam, reverse=True)[:10]
szamtani_kozepe = sum(legnagyobbak) / len(legnagyobbak)
print(szamtani_kozepe)


print("2. feladat")
print(f'Az 1. sorban szereplő 15 legkisebb szám szorzatának nagyságrendje:10^{(len(str(sz)))}')

print("3. feladat")
print(f'A 2. sorban szereplő páros számok minimuma: {minimum}')

print("4. feladat")
print(f'A 3. sorban szereplő 3-mal osztható számok összege: {osszegg}')

print("5. feladat")
print(f'A 4. sorban szereplő számok maximuma: {maximum}')

print("6. feladat")
print(f'Az 5. sorban szereplő 15-nél kisebb számok négyzeteinek összege: {osszeg}')

print("7. feladat")
print(f'Az inputban szereplő összes szám közül a 10 legnagyobb szám számtaniközepe: {szamtani_kozepe}')
